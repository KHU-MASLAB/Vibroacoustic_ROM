clear
clc

% -------------------------------------------------------------------------
%
% Fluid-Structure Interaction for 2D model: 6.1 Fluid box problem
% Soo Min Kim 2017-07-18
% Jin-Gyun Kim modified 2021-07-01
% Department of Mechanical Enginering
% Kyung Hee University
% Ref: Kim, S. M., Kim, J. G., Chae, S. W., & Park, K. C. (2019). A strongly coupled model reduction of vibro-acoustic interaction. Computer Methods in Applied Mechanics and Engineering, 347, 495-516.
% This code provides Figure 3 and Figure 4 in the reference.
%
% -------------------------------------------------------------------------


%% 01 ---------------------------------------------------------------------

dof_fl = [ 1:1:189 ]'; % fluid has 189 nodes
el_no_fl = [ 1:1:160 ]'; % fluid has 160 elements

first_el = [ 1 2 23 22 ]; % element �� is defined by nodes 1-2-23-22 (quad element)
first_el_row = [ ];

for i = 1 : 20
    
    first_el_row = [ first_el_row ; first_el + (i-1) ];
    % composition of first row elements
    % (element number) | node1 | node2 | node3 | node4
    
end

all_el_fl = [ ];

for i = 1 : 21 : 160
    
    all_el_fl = [ all_el_fl ; first_el_row + (i-1) ];
    % composition of all fluid elements
    % (element number) | node1 | node2 | node3 | node4 
    
end

edof_fl = [ el_no_fl,all_el_fl ]; 
% element number | node1 , node2 , node3 , node4

x_coord_first_node_row = [ 0:0.5:10 ]';
y_coord_first_node_row = zeros( 21,1 );

coord_first_node_row = [ x_coord_first_node_row,y_coord_first_node_row ];
% (x,y) coordinates of bottom 21 nodes

coord_fl = [ ];

add = [ zeros(21,1),zeros(21,1)+0.5 ];

for i = 1 : 1 : 9
    
    coord_fl = [ coord_fl ; coord_first_node_row + (i-1)*add ];
    % bottom line + 0.5 (in y-direction)
    % (x,y) coordinates of all fluid nodes
    
end





% 02 ---------------------------------------------------------------------

% plotpar = [ 3,1,1 ]; 
% plot style
% [solid/dashed/dotted] , [black/blue/magenta/red] , [circle/star/nomark]

[ ex_fl,ey_fl ] = coordxtr( edof_fl,coord_fl,dof_fl,4 );
% ex_fl : (element number) | node1_x | node2_x | node3_x | node4_x
% ey_fl : (element number) | node1_y | node2_y | node3_y | node4_y

% figure(1)
% eldraw2( ex_fl,ey_fl,plotpar,edof_fl( :,1 ) ); 





% 03 ---------------------------------------------------------------------
% Fluid matrices

ep_fl = [ 1 1500 1000 3 ];
% [ thickness | speed of sound | density | integration rule ]

ndof_fl = max( max( dof_fl ) );

K_fl = zeros( ndof_fl,ndof_fl );
M_fl = K_fl;

for i =  1 : length( ex_fl )
    
    [ ke_fl,me_fl ] = aco2i4d( ex_fl( i,: ),ey_fl( i,: ),ep_fl );
    % aco2i4d : generate 2D 4node acoustic element
    % by | coordinates | and | property |
    
    K_fl = assem( edof_fl( i,: ),K_fl,ke_fl );
    M_fl = assem( edof_fl( i,: ),M_fl,me_fl );
    % assem : construct full matrix
    % by global and local relationship
    
end

[ La_fl,p_fl ] = eigen( K_fl,M_fl );

freq_fl = sqrt( La_fl ) / 2 / pi; % rad/s <-> Hz





%% 04 ---------------------------------------------------------------------

% modnr = 1;
% 
% figure(2)
% for j = 1 : 3
%     
%     for i = 1 : 3
%         
%         modnr = modnr + 1;
%         Ed = extract( edof_fl,p_fl( :,modnr) ); % element deflection ? 
%         Edabs = abs( Ed );
%         const = max( max( Edabs ) );
%         Ed = Ed / const;
%         h = fill( ex_fl' + 10*1.1*(i-1),     ey_fl' - 4*1.6*(j-1),     Ed' );
%         MOD = num2str( freq_fl( modnr ) );
%         
%         text( 10*1.1*(i-1)+4, -4*1.6*(j-1)-1,MOD )
%         set( h,'edgecolor','black' )
%         
%         % plot modeshapes of free fluid element
%         
%         hold on
%         
%     end
%     
% end
% 
% axis equal
% axis off





%% 05 ---------------------------------------------------------------------

el_no_st = [ 1:1:20 ]'; % structure domain has 20 elements
coord_st = [ [0:0.5:10]',4*ones(21,1) ]; % (element number) | node i_x | node i_y

first_dof_st = [ 1:3:61 ]'; % first dof of each node in structure (1-4-7-10-13-16-...-61)
dof_st = [ first_dof_st,first_dof_st+1,first_dof_st+2 ];
% (element number) | dof_1 | dof_2 | dof_3

first_edof_st = [ 1 2 3 4 5 6 ];
all_el_st = [ ];

for i = 1 : 1 : 20
    
    all_el_st = [ all_el_st ; first_edof_st+3*(i-1) ];
    % (element number) | dof of first node | dof of second node
    
end

edof_st = [ el_no_st,all_el_st ];

plotpar = [ 3,1,1 ];
[ ex_st,ey_st ] = coordxtr( edof_st,coord_st,dof_st,2 );
 
% figure()
% eldraw2( ex_st,ey_st,plotpar,edof_st(:,1) );





%% 06 ---------------------------------------------------------------------
% Structure Matrices

ndof_st = max( max( dof_st ) );

E = 2.1e11;
A = 0.02;
I = 1.59e-4;
m = A*2500;
ep_st = [ E A I m ];

K_st = zeros( ndof_st,ndof_st );
M_st = K_st;

for i = 1 : length( ex_st )
    
    [ ke_st,me_st ] = beam2d( ex_st( i,: ),ey_st( i,: ),ep_st );
    
    K_st = assem( edof_st( i,: ),K_st,ke_st );
    M_st = assem( edof_st( i,: ),M_st,me_st );
    end






%% 07 ---------------------------------------------------------------------

edof_coup_st = edof_st; % element number | node 1 dof | node 2 dof

el_no_coup_fl = [ 141:1:160 ]'; % FL element 141 to 160 are coupled with ST

first_edof_coup_fl = [ 169 170 ];

all_el_coup_fl = [ ];

for i = 1 : 1 : 20
    
    all_el_coup_fl = [ all_el_coup_fl ; first_edof_coup_fl + (i-1) ];
    
end

edof_coup_fl = [ el_no_coup_fl,all_el_coup_fl ]; % element number | node 1 dof | node 2 dof 




%% 08 ---------------------------------------------------------------------

H = zeros( ndof_st,ndof_fl );

for i = 1 : length( ex_st )
    
    he = cp2s2f( ex_st(i,:),ey_st(i,:),1 );
    % he : element coupling matrix [6x2]
    % 1 : thickness
    H = assem_ns( edof_coup_st( i,: ),edof_coup_fl( i,: ),H,he );
    % edof_coup_st -> 1 | 1 2 3 4  5  6
    %                 2 | 4 5 6 7  8  9
    %                 3 | 7 8 9 10 11 12 ...
    
    % edof_coup_fl -> 141 | 169 170
    %                 142 | 170 171 ...
    
end

b = [ 1 2 61 62 ];
H( b,: ) = [];

M_st( b,: ) = [];
M_st( :,b ) = [];
K_st( b,: ) = [];
K_st( :,b ) = [];

[ La_st,p_st ] = eigen( K_st,M_st ); 
freq_st = sqrt( La_st )/2/pi;





%% 09 Full model

zeroH = 0 * H;

rho = 1000;
c = 1500;

M0 = [ M_st             zeroH;
       rho*c^2*H'       M_fl ];
  
K0 = [ K_st            -H;
       zeroH'           K_fl ];

[ p,l ] = eigs( K0,M0,length(K0),0.001 );
l = sort( diag( l ));
freq_p = sqrt( l )/2/pi;






%% 10 Uncoupled

ndst = 1:7;
ndfl = 1:18;

% 100 = 12 + 88
% 150 = 14 + 136
% 200 = 17 + 183

p_st_d = p_st( :,ndst );
p_fl_d = p_fl( :,ndfl );

a = size( p_st_d,1 );
b = size( p_st_d,2 );
c = size( p_fl_d,1 );
d = size( p_fl_d,2 );

T = [ p_st_d            zeros( a,d );
      zeros( c,b )      p_fl_d ];

Mr = T' * M0 * T;
Kr = T' * K0 * T;

[ pr,lr ] = eigs( Kr,Mr,length(Kr),0.001 );
lr = sort( diag( lr ));
freq_pr = abs( sqrt( lr ))/2/pi;






%% 11 Weakly coupled

Psi = K_st \ H;

TT = [ p_st_d             Psi*p_fl_d;
       zeros( c,b )       p_fl_d];

Mrr = TT' * M0 * TT;
Krr = TT' * K0 * TT;

[ prr,lrr ] = eigs( Krr,Mrr,length(Krr),0.001 );
lrr = sort( diag( lrr ));
freq_prr = abs( sqrt( lrr ))/2/pi;








%% 12 --------------------------------------------------------------------- Standard reduction (strongly coupled)

% with low
M_fl_hat = M_fl + (Psi'*M_st + rho*1500^2*H')*Psi;

% with low and high
% M_fl_hat = M_fl + 1000*1500^2*H'*p_st*inv(diag(La_st))*p_st'*H + H'*p_st*inv(diag(La_st)).^2*p_st'*H;

K_fl_hat = K_fl;

[ La_fl_hat,p_fl_hat ] = eigen( K_fl_hat,M_fl_hat );

p_fl_hat_d = p_fl_hat( :,ndfl );

TTT = [ p_st_d             Psi*p_fl_hat_d;
        zeros( c,b )       p_fl_hat_d];

Mrrr = TTT' * M0 * TTT;
Krrr = TTT' * K0 * TTT;

[ prrr,lrrr ] = eigs( Krrr,Mrrr,length(Krrr),0.001 );
lrrr = sort( diag( lrrr ));
freq_prrr = abs( sqrt( lrrr ))/2/pi;






%% Figure

target = length( freq_pr );

for i = 2 : target
   
    e1( i,1 ) = (freq_p(i,1)-freq_pr(i,1)) / freq_p(i,1);
    e2( i,1 ) = (freq_p(i,1)-freq_prr(i,1)) / freq_p(i,1);
    e3( i,1 ) = (freq_p(i,1)-freq_prrr(i,1)) / freq_p(i,1);
        
end

e1 = abs( e1 );
e2 = abs( e2 );
e3 = abs( e3 );

figure()
semilogy( e1, 'c','Markersize',12,'linewidth',3 )
hold on
semilogy( e2, 'b-*','Markersize',12 )
hold on
semilogy( e3, 'r-o','Markersize',12 )
title('Relative frequency error (Standard form)')
legend( 'Basic','Weak','Strong','Location','southeast' )
legend( 'boxoff' )
xlabel( 'Mode number' )
ylabel( 'Relative error' )
xlim([0 15])


%% Figure 2

kkk = length( freq_pr );
kkk = min( kkk,20 );
kkk = length( freq_prrr );

% figure()
% semilogy( freq_p( 2:kkk ), 'k-square','Markersize',12 )
% hold on
% semilogy( freq_pr( 2:kkk,1 ), 'c','Markersize',12,'linewidth',3 )
% hold on
% semilogy( freq_prr( 2:kkk,1 ), 'b-*','Markersize',12 )
% hold on
% semilogy( freq_prrr( 2:kkk,1 ), 'r-o','Markersize',12 )
% title( 'Natural Frequency' )
% legend( 'Full','Un','Weak','Strong','Location','southeast' )
% legend( 'boxoff' )

figure()
plot( freq_p( 2:kkk ), 'k-square','Markersize',12 )
hold on
plot( freq_pr( 2:kkk,1 ), 'c','Markersize',12,'linewidth',3 )
hold on
plot( freq_prr( 2:kkk,1 ), 'b-*','Markersize',12 )
hold on
plot( freq_prrr( 2:kkk,1 ), 'r-o','Markersize',12 )
title( 'Natural Frequency' )
legend( 'Full','Un','Weak','Strong','Location','southeast' )
legend( 'boxoff' )
xlim([0 15])



%% norm

rho = 1000;
c = 1500;

low = norm( rho * c^2 * H' * inv(K_st) * H );
high = norm( H' * p_st * inv(diag(La_st)).^2 * p_st' * H );








clc
return




















%% Frequency Response function

step = 0:1:10000;
t = length( step );
H = cell( t,1 );
Hr = cell( t,1 );
Hrr = cell( t,1 );
Hrrr = cell( t,1 );


for i = 1 : t
    
    H{ i,1 } = inv( K0 - step(1,i)^2 * M0 );
    Hr{ i,1 } = inv( K0r - step(1,i)^2 * M0r );
    Hrr{ i,1 } = inv( K0rr - step(1,i)^2 * M0rr );
    Hrrr{ i,1 } = inv( K0rrr - step(1,i)^2 * M0rrr );
    
end

H11 = zeros( t,1 );
Hr11 = zeros( t,1 );
Hrr11 = zeros( t,1 );
Hrrr11 = zeros( t,1 );

alpha = 1;
beta = 1;

for i = 1 : t
    
    H11( i,1 ) = H{ i,1 }( alpha,beta );
    Hr11( i,1 ) = Hr{ i,1 }( alpha,beta );
    Hrr11( i,1 ) = Hrr{ i,1 }( alpha,beta );
    Hrrr11( i,1 ) = Hrrr{ i,1 }( alpha,beta );
            
end




figure()
subplot( 2,2,1 )
semilogy( step,abs(H11),'k' );
title( 'Reference' )
subplot( 2,2,2 )
semilogy( step,abs(Hr11),'magenta' );
title( 'Basic reduction' )
subplot( 2,2,3 )
semilogy( step,abs(Hrr11),'b' );
title( 'Weak reduction' )
subplot( 2,2,4 )
semilogy( step,abs(Hrrr11),'r' );
title( 'Strong reduction' )




clc